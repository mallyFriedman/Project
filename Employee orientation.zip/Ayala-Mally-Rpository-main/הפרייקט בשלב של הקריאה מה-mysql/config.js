const config = {
    db: {
        host: "localhost",
        user: "root",
        password: "1234",
        database: 'helper'  
    },
    listPerPage: 10,
 };

 module.exports = config;
