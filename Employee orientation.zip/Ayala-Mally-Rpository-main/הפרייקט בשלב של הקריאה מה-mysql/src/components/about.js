import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react'

export default function About() {
    let nevigate = useNavigate();

    return (
        <div className="About">
            <p>ayala min hahay</p>
        </div>
    );
}



