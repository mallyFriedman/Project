Job Matching Website
Project Description
This website connects employees with employers. Users can sign up as an employee and see if there are any job matches based on their criteria. The system filters and matches based on specified characteristics, and when everything aligns, a match is made. If a user searches for a job and no match is found, the search details are saved, and the user will be notified when a matching job becomes available.

How to Run the Project
Download all the project folders.
Navigate to the directory: name/src.
Inside, you'll find the project's components.
It is recommended to start from the homepage and follow the instructions provided there.
Hope you enjoy,
Project Creator: Meli Greenwald

