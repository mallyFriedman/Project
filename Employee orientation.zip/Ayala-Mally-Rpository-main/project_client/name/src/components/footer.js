import React from "react";
import { NavLink } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
import '../Css/footer.css'

export default function Footer(props) {



    return (
        <nav >
            <h1>____________________________________________________________________________</h1>
            <div className="div">
            <h1>thank you for using our webSite</h1>
                <br></br>
                😀😁😂
                <br></br>
              </div>
        </nav>
    );
}




